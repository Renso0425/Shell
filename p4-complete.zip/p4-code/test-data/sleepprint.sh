#!/bin/bash
# 
# Sleep then print a message

sleeptime=$1
shift
sleep $sleeptime
echo $*

