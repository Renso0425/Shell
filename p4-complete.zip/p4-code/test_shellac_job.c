// test_shellac_job.c: testing program for functions in shellac_job.c

// emacs setting to skip between tests via outline mode
// (progn (setq outline-regexp " *IF_TEST") (outline-minor-mode))

#include "shellac.h"

// macro to set up a test with given name, print the source of the
// test; very hacky, fragile, but useful
#define IF_TEST(TNAME) \
  if( RUNALL || strcmp( TNAME, test_name)==0 ) { \
    sprintf(sysbuf,"awk 'NR==(%d){P=1;gsub(\"^ *\",\"\");} P==1 && /ENDTEST/{P=0; print \"}\\n---OUTPUT---\"} P==1{print}' %s", __LINE__, __FILE__); \
    system(sysbuf); nrun++;  \
  } \
  if( RUNALL || strcmp( TNAME, test_name)==0 )


char sysbuf[1024];
int RUNALL = 0;
int nrun = 0;

int main(int argc, char *argv[]){
  setvbuf(stdout, NULL, _IONBF, 0); // Turn off buffering

  if(argc < 2){
    printf("usage: %s <test_name>\n", argv[0]);
    return 1;
  }
  char *test_name = argv[1];
  if(strcmp("ALL",test_name)==0){
    RUNALL = 1;
  }

  ////////////////////////////////////////////////////////////////////////////////
  // Problem 2 tests

  IF_TEST("job_print 1") {
    // Tests presence of the job_print() function and whether it produces
    // correct output for an "empty" job.
    job_t job = {
      .jobname       = "",
      .pid           = 0,
      .retval        = 0,
      .condition     = JOBCOND_UNSET,
      .output_file   = NULL,
      .input_file    = NULL,
      .is_background = 0,
      .argc          = 0,
      .argv = { NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job_print 2") {
    // Check output of job printing for a running job
    job_t job = {
      .jobname       = "ls",
      .pid           = 1234,
      .retval        = -1,
      .condition     = JOBCOND_RUN,
      .output_file   = NULL,
      .input_file    = NULL,
      .is_background = 0,
      .argc          = 2,
      .argv = { "ls", "-l", NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job_print 3") {
    // Check output of job printing for a completed job
    job_t job = {
      .jobname       = "gcc",
      .pid           = 56789,
      .retval        = 0,
      .condition     = JOBCOND_EXIT,
      .output_file   = NULL,
      .input_file    = NULL,
      .is_background = 0,
      .argc          = 6,
      .argv = { "gcc", "-o", "myprog", "-g", "myprog.c", "util.c", NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job_print 4") {
    // Check output of job printing for a failed job
    job_t job = {
      .jobname       = "no_command",
      .pid           = 8765,
      .retval        = -1,
      .condition     = JOBCOND_FAIL_EXEC,
      .output_file   = NULL,
      .input_file    = NULL,
      .is_background = 0,
      .argc          = 3,
      .argv = { "no_command", "arg1", "arg2", NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job_print 5") {
    // Check output of job printing for a job with output file
    // redirection run in the background
    job_t job = {
      .jobname       = "diff",
      .pid           = 2378,
      .retval        = 1,
      .condition     = JOBCOND_EXIT,
      .output_file   = "diff_output.txt",
      .input_file    = NULL,
      .is_background = 1,
      .argc          = 3,
      .argv = { "diff", "file1.txt", "file2.txt", NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job_print 6") {
    // Check output of job printing for a job with both input/output
    // file redirection
    job_t job = {
      .jobname       = "wc",
      .pid           = 4011,
      .retval        = -1,
      .condition     = JOBCOND_RUN,
      .output_file   = "count.dat",
      .input_file    = "bigfile.txt",
      .is_background = 0,
      .argc          = 2,
      .argv = { "wc", "-l", NULL },
    };
    job_print(&job);
  } // ENDTEST

  IF_TEST("job new/free 1") {
    // Create a new job via job_new(); print it to see that the fields
    // look correct, job is in in the initial state, etc. Then
    // de-allocate via job_free().
    char *args[] = {
      "ls", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST


  IF_TEST("job new/free 2") {
    // Create a new job via job_new(); print it to see that the fields
    // look correct, job is in in the initial state, etc. Then
    // de-allocate via job_free().
    char *args[] = {
      "gcc", "-o", "myprog", "-g", "myprog.c", "util.c", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start 1") {
    // Create a new job via job_new() then start it; check to ensure
    // that the status within the job changes properly. 
    char *args[] = {
      "echo", "Run", "job", "run!", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);  // ensure child finishes with any output flushed
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start 2") {
    // Create a new job via job_new() then start it; check to ensure
    // that the status within the job changes properly. 
    char *args[] = {
      "test-data/table.sh", "3", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);  // ensure child finishes with any output flushed
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start 3") {
    // Create a new job via job_new() then start it; check to ensure
    // that the status within the job changes properly. 
    char *args[] = {
      "seq", "0", "5", "30", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);  // ensure child finishes with any output flushed
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job update 1") {
    // New job via job_new(), started via job_start(), then update its
    // status via job_update_status(). For these non-background jobs,
    // this should wait on the child process, then update the job_t
    // with the completed job status.
    char *args[] = {
      "echo", "Run", "job", "run!", NULL,
    };
    job_t *job = job_new(args);
    job_start(job);
    int ret = job_update_status(job);
    printf("ret: %d\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job update 2") {
    // New job via job_new(), started via job_start(), then update its
    // status via job_update_status(). For these non-background jobs,
    // this should wait on the child process, then update the job_t
    // with the completed job status.
    //
    // This version has a non-zero exit status for the child.
    char *args[] = {
      "cat", "nonexistent.txt", NULL,
    };
    job_t *job = job_new(args);
    job_start(job);
    int ret = job_update_status(job);
    printf("ret: %d\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job update 3") {
    // New job via job_new(), started via job_start(), then update its
    // status via job_update_status(). For these non-background jobs,
    // this should wait on the child process, then update the job_t
    // with the completed job status.
    //
    // This version has a non-zero exit status for the child.
    char *args[] = {
      "diff", "nope.txt", "not_there.txt", NULL,
    };
    job_t *job = job_new(args);
    job_start(job);
    int ret = job_update_status(job);
    printf("ret: %d\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job update fail 1") {
    // Start a job that fails to exec() properly. This checks that
    // this type of failure is detected in job_start() and caught in
    // job_update().
    char *args[] = {
      "not_a_valid_command", "arg1", "arg2", NULL,
    };
    job_t *job = job_new(args);
    job_start(job);
    int ret = job_update_status(job);
    printf("ret: %d\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job run") {
    // Start a slow job and print its status while running; relies on
    // sleep to be slow and may be flakey in practice
    char *args[] = {
      "sleep", "0.25", NULL,
    };
    job_t *job = job_new(args);
    printf("---Job Created---\n");
    job_print(job);
    job_start(job);
    printf("---Job Running---\n");
    job_print(job);
    int ret = job_update_status(job);
    printf("---Job Complete: ret %d---\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new out 1") {
    // Checks that a new job created with the output redirection
    // syntax ">" correctly parses the args array to identify the
    // trailing output file. This is removed from the command line and
    // assigned to the job->outputfile field.
    char *args[] = {
      "ls", ">", "output.txt", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new out 2") {
    // Checks that a new job created with the output redirection
    // syntax ">" correctly parses the args array to identify the
    // trailing output file. This is removed from the command line and
    // assigned to the job->outputfile field.
    //
    // A slightly more elaborate case than the first test
    char *args[] = {
      "ascii","-t","x","y","z",">","test-results/output.tmp",NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new out error") {
    // Detect if output redirection ">" appears but there is not
    // trailing file. This should print an error and return NULL.
    char *args[] = {
      "ascii","x",">",NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    // No need ot free() as job should be NULL
  } // ENDTEST

  IF_TEST("job new in 1") {
    // Checks that a new job created with the output redirection
    // syntax "<" correctly parses the args array to identify the
    // trailing input file. This is removed from the command line and
    // assigned to the job->inputfile field.
    char *args[] = {
      "wc", "<", "input.txt", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new in 2") {
    // Checks that a new job created with the output redirection
    // syntax "<" correctly parses the args array to identify the
    // trailing input file. This is removed from the command line and
    // assigned to the job->inputfile field.
    // 
    // A slightly more elaborate case than the first test
    char *args[] = {
      "wc","-l","-b", "<", "input.txt", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new in error") {
    // Detect if input redirection "<" appears but there is not
    // trailing file. This should print an error and return NULL.
    char *args[] = {
      "cat","<",NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    // No need ot free() as job should be NULL
  } // ENDTEST

  ////////////////////////////////////////////////////////////////////////////////
  // Problem 3 tests

  IF_TEST("job new out in 1") {
    // Checks that a new job created both output/input redirection is
    // handled correctly to assign appropriate fields to each.
    char *args[] = {
      "wc","-l","-b", "<", "infile.txt",">", "outfile.txt", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new out in 2") {
    // Checks that a new job created both output/input redirection is
    // handled correctly to assign appropriate fields to each.
    //
    // Revierses the order of input/output file placement
    char *args[] = {
      "ascii","z",">", "zeout.txt", "<", "zeinp.txt", NULL,
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start out 1") {
    // Run a job that redirects output into a file then show the
    // contents of that file to ensure it was created correctly.
    char *args[] = {
      "echo", "hello","output",
      ">", "test-results/output.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
    printf("Contents of output.tmp:\n");
    system("cat test-results/output.tmp");
  } // ENDTEST

  IF_TEST("job start out 2") {
    // Run a job that redirects output into a file then show the
    // contents of that file to ensure it was created correctly.
    char *args[] = {
      "seq", "1","3","20",
      ">", "test-results/seqout.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
    printf("Contents of seqout.tmp:\n");
    system("cat test-results/seqout.tmp");
  } // ENDTEST

  IF_TEST("job output truncates") {
    // Test to ensure that output redirection "clobbers" files that it
    // redirects to. This is typically achieved by passing the O_TRUNC
    // flag to open() when creating the file that is to be output
    // to. The test works by creating long file then running a job
    // that redirects a small amount of input into it. If the trailing
    // output is the original file, then truncation hasn't been set up.
    system("seq 7001 7010 > test-results/truncout.tmp");
    char *args[] = {
      "echo", "Overwrite","now!",
      ">", "test-results/truncout.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
    printf("Contents of truncout.tmp:\n");
    system("cat test-results/truncout.tmp");
    
  } // ENDTEST

  IF_TEST("job start in 1") {
    // Put some input in a file then start a job that redirects the
    // file contents as input to the job.
    system("seq 10 > test-results/nums.tmp");
    char *args[] = {
      "wc", 
      "<", "test-results/nums.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start in 2") {
    // Run a job that redirects output into a file then show the
    // contents of that file to ensure it was created correctly.
    system("seq 0 5 100 > test-results/nums100.tmp");
    char *args[] = {
      "head","-n","8", 
      "<", "test-results/nums100.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
  } // ENDTEST

  IF_TEST("job start in/out 1") {
    // Run a job that redirects both input and output.
    system("seq 0 5 100 > test-results/nums100.tmp");
    char *args[] = {
      "head","-n","8", 
      "<", "test-results/nums100.tmp",
      ">", "test-results/firstnums.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
    printf("---Contents of firstnums.tmp---\n");
    system("cat test-results/firstnums.tmp");
  } // ENDTEST

  IF_TEST("job start in/out 2") {
    // Run a job that redirects both input and output.
    system("seq 0 5 100 > test-results/nums100.tmp");
    char *args[] = {
      "tail","-n","6", 
      ">", "test-results/firstnums.tmp",
      "<", "test-results/nums100.tmp",
      NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_start(job);
    wait(NULL);
    job_free(job);
    printf("---Contents of firstnums.tmp---\n");
    system("cat test-results/firstnums.tmp");
  } // ENDTEST

  IF_TEST("job new bg 1") {
    // Create a job with background "&" present and check that it is
    // parsed correctly, has is_background field set.
    char *args[] = {
      "ls","&", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new bg 2") {
    // Create a job with background "&" present and check that it is
    // parsed correctly, has is_background field set. Position of & is
    // further into the commands.
    char *args[] = {
      "wc","-l", "some-file.txt", "&", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST
  

  IF_TEST("job new bg 3") {
    // Mixture of input/outpt redirection and background job symbol in
    // the args array to check for proper parsing
    char *args[] = {
      "wc","-l", "some-file.txt",
      ">","outfile.txt",
      "&", NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job new bg 4") {
    // Mixture of input/outpt redirection and background job symbol in
    // the args array to check for proper parsing
    char *args[] = {
      "wc","-l", "some-file.txt",
      "&",
      "<","infile.txt",
      ">","outfile.txt",
       NULL
    };
    job_t *job = job_new(args);
    job_print(job);
    job_free(job);
  } // ENDTEST

  IF_TEST("job update bg") {
    // Start a slow backgorund job and verify that calling
    // job_update() on it does not block. Background jobs should be
    // waited on using the WNOHANG flag so that there is no blocking
    // in the parent.
    char *args[] = {
      "sleep", "0.25","&", NULL,
    };
    job_t *job = job_new(args);
    printf("---Job Created---\n");
    job_print(job);
    job_start(job);
    printf("---Job Running---\n");
    job_print(job);

    int ret = job_update_status(job);
    printf("---Job Still Running: ret %d---\n",ret);
    job_print(job);

    system("sleep 0.30"); // sleep a moment to let child finish
    ret = job_update_status(job);
    printf("---Job Complete: ret %d---\n",ret);
    job_print(job);
    job_free(job);
  } // ENDTEST
  

  if(nrun == 0){
    printf("No test named '%s' found\n",test_name);
    return 1;
  }

  return 0;
}
