// test_shellac_control.c: testing program for functions in shellac_control.c

// emacs setting to skip between tests via outline mode
// (progn (setq outline-regexp " *IF_TEST") (outline-minor-mode))

#include "shellac.h"

// macro to set up a test with given name, print the source of the
// test; very hacky, fragile, but useful
#define IF_TEST(TNAME) \
  if( RUNALL || strcmp( TNAME, test_name)==0 ) { \
    sprintf(sysbuf,"awk 'NR==(%d){P=1;gsub(\"^ *\",\"\");} P==1 && /ENDTEST/{P=0; print \"}\\n---OUTPUT---\"} P==1{print}' %s", __LINE__, __FILE__); \
    system(sysbuf); nrun++;  \
  } \
  if( RUNALL || strcmp( TNAME, test_name)==0 )


char sysbuf[1024];
int RUNALL = 0;
int nrun = 0;

int main(int argc, char *argv[]){
  setvbuf(stdout, NULL, _IONBF, 0); // Turn off buffering

  if(argc < 2){
    printf("usage: %s <test_name>\n", argv[0]);
    return 1;
  }
  char *test_name = argv[1];
  if(strcmp("ALL",test_name)==0){
    RUNALL = 1;
  }


  IF_TEST("control init print") {
    // Initialize an empty shellac struct and print it out
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST

  IF_TEST("control add 1") {
    // Initialize an empty shellac struct, add a job to it, then print
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    job_t job0 = {
      .jobname       = "top_job0",
    };
    shellac_add_job(shellac,&job0);
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST

  IF_TEST("control add 2") {
    // Initialize an empty shellac struct, add a couple jobs to it,
    // then print.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    job_t job0 = {
      .jobname       = "gcc_job0",
    };
    job_t job1 = {
      .jobname       = "ls_job1",
    };
    shellac_add_job(shellac,&job0);
    shellac_add_job(shellac,&job1);
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST

  IF_TEST("control add remove 1") {
    // Initialize an empty shellac struct, add a job to it, then
    // remove it. Removed jobs are expected to be de-allocated with
    // job_free() so must be heap-allocated.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[] = { "sleep", "5", NULL};
    job_t *job = job_new(args);
    shellac_add_job(shellac,job);
    printf("\n---After Add---\n");
    shellac_print_jobs(shellac);
    shellac_remove_job(shellac,0); 
    printf("\n---After Remove---\n");
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST

  IF_TEST("control start 1") {
    // Add a job then start it; towards job control at a higher level.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[] = { "echo", "Away", "we", "go...", NULL};
    job_t *job = job_new(args);

    printf("\n---Add---\n");
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);

    printf("\n---Start---\n");
    shellac_start_job(shellac,0);
    wait(NULL);                 // ensure child output first
    shellac_print_jobs(shellac);

    printf("\n---Remove---\n");
    shellac_remove_job(shellac,0);
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST


  IF_TEST("control start update 1") {
    // Add a job then start it the update its
    // status. Foreground jobs shold cause the parent (test
    // program in this case) to wait until the child is
    // done.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[] = {
      "bash", "-c",
      "sleep 0.25 && echo child says Job Complete",
      NULL
    };
    job_t *job = job_new(args);

    printf("\n---Add---\n");
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);   // rely on sleep to for output order

    printf("\n---Start---\n");
    shellac_start_job(shellac,0);
    shellac_print_jobs(shellac);   // rely on sleep to for output order

    printf("\n---Update---\n");
    shellac_update_one(shellac,0); // waits on child process, shows exit
    shellac_print_jobs(shellac);   // job automatically removed

    printf("\n---Already Removed Error---\n");
    shellac_remove_job(shellac,0); 
    free(shellac);
  } // ENDTEST


  IF_TEST("control update all 1") {
    // Add a job then start it the update its
    // status. Foreground jobs shold cause the parent (test
    // program in this case) to wait until the child is
    // done.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[] = {
      "bash", "-c",
      "sleep 0.25 && echo child says Job Complete",
      NULL
    };
    job_t *job = job_new(args);

    printf("\n---Add---\n");
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);   // rely on sleep to for output order

    printf("\n---Start---\n");
    shellac_start_job(shellac,0);
    shellac_print_jobs(shellac);   // rely on sleep to for output order

    printf("\n---Update All---\n");
    shellac_update_all(shellac); // waits on ALL child processes, shows exit
    shellac_print_jobs(shellac); // job automatically removed

    free(shellac);
  } // ENDTEST


  IF_TEST("control add many") {
    // Initialize an empty shellac struct, add several jobs to it,
    // then print.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    job_t jobs[] = {
      {.jobname = "wc_-l"},
      {.jobname = "gcc"},
      {.jobname = "seq_1_10"},
      {.jobname = "sleep_5"},
      {.jobname = "top"},
      {.jobname = ""},
    };
    for(int i=0; jobs[i].jobname[0]!='\0'; i++){
      shellac_add_job(shellac,&jobs[i]);
    }
    shellac_print_jobs(shellac);
    free(shellac);
  } // ENDTEST


  IF_TEST("control add remove 2") {
    // Initialize an empty shellac struct, add jobs to it, then remove
    // them. Expectation is that removed jobs that are early create
    // NULL entries in the array of jobs but are not printed.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[10][10] = {
      {"sleep", "5", NULL},
      {"gcc","myprog.c","-g",NULL},
      {""},
    };
    job_t *job;

    printf("\n---Add 2---\n");
    job = job_new(args[0]);
    shellac_add_job(shellac,job);
    job = job_new(args[1]);
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);

    printf("\n---Remove 0---\n");
    shellac_remove_job(shellac,0);
    shellac_print_jobs(shellac);

    printf("\n---Remove 1---\n");
    shellac_remove_job(shellac,1);
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST

  IF_TEST("control add remove many") {
    // Initialize an empty shellac struct, add jobs to it, then remove
    // them. Expectation is that removed jobs that are early create
    // NULL entries in the array of jobs but are not printed.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[10][10] = {
      {"aaa","aaa",NULL},
      {"bbb","bbb",NULL},
      {"ccc","ccc",NULL},
      {"ddd","ddd",NULL},
      {"eee","eee",NULL},
      {"fff","fff",NULL},
      {""},
    };

    printf("\n---Add All---\n");
    for(int i=0; args[i][0][0] != '\0'; i++){
      job_t *job = job_new(args[i]);
      shellac_add_job(shellac,job);
    }
    shellac_print_jobs(shellac);

    printf("\n---Remove 3---\n");
    shellac_remove_job(shellac,3);
    shellac_print_jobs(shellac);

    printf("\n---Remove 1---\n");
    shellac_remove_job(shellac,1);
    shellac_print_jobs(shellac);

    printf("\n---Remove 2 4---\n");
    shellac_remove_job(shellac,2);
    shellac_remove_job(shellac,4);
    shellac_print_jobs(shellac);

    printf("\n---Remove 0 5---\n");
    shellac_remove_job(shellac,0);
    shellac_remove_job(shellac,5);
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST

  IF_TEST("control add remove many") {
    // Initialize an empty shellac struct, add jobs to it, then remove
    // them. Expectation is that removed jobs that are early create
    // NULL entries in the array of jobs but are not printed.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[10][10] = {
      {"aaa","aaa",NULL},  // 0
      {"bbb","bbb",NULL},  // 1
      {"ccc","ccc",NULL},  // 2
      {"ddd","ddd",NULL},  // 3
      {"eee","eee",NULL},  // 4
      {"fff","fff",NULL},  // 5
      {""},                // 6
      {"xxx","xxx",NULL},  // 7
      {"yyy","yyy",NULL},  // 8
      {"zzz","zzz",NULL},  // 9
      
    };

    printf("\n---Add All---\n");
    for(int i=0; i<6; i++){
      job_t *job = job_new(args[i]);
      shellac_add_job(shellac,job);
    }
    shellac_print_jobs(shellac);

    printf("\n---Remove 3 1---\n");
    shellac_remove_job(shellac,3);
    shellac_remove_job(shellac,1);
    shellac_print_jobs(shellac);

    printf("\n---Add 7---\n");
    job_t *job;
    job = job_new(args[7]);
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);
    
    printf("\n---Remove 4---\n");
    shellac_remove_job(shellac,4);
    shellac_print_jobs(shellac);

    printf("\n---Add 8 9---\n");
    job = job_new(args[8]);
    shellac_add_job(shellac,job);
    job = job_new(args[9]);
    shellac_add_job(shellac,job);
    shellac_print_jobs(shellac);

    for(int i=0; i<6; i++){
      shellac_remove_job(shellac,i);
    }
    printf("\n---Remove All---\n");
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST

  IF_TEST("control remove error") {
    // Initialize an empty shellac struct, add jobs to it, then remove
    // them. Expectation is that removed jobs that are early create
    // NULL entries in the array of jobs but are not printed.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    shellac_remove_job(shellac,0);
    shellac_remove_job(shellac,3);

    char *args[10][10] = {
      {"aaa","aaa",NULL},  // 0
      {"bbb","bbb",NULL},  // 1
      {"ccc","ccc",NULL},  // 2
      {"ddd","ddd",NULL},  // 3
      {"eee","eee",NULL},  // 4
      {"fff","fff",NULL},  // 5
      {""},                // 6
      {"xxx","xxx",NULL},  // 7
      {"yyy","yyy",NULL},  // 8
      {"zzz","zzz",NULL},  // 9
      
    };
    printf("\n---Add All---\n");
    for(int i=0; i<6; i++){
      job_t *job = job_new(args[i]);
      shellac_add_job(shellac,job);
    }
    shellac_print_jobs(shellac);

    printf("\n---Remove 4 2---\n");
    shellac_remove_job(shellac,4);
    shellac_remove_job(shellac,2);
    shellac_print_jobs(shellac);
    
    printf("\n---Failed Remove 4 2---\n");
    shellac_remove_job(shellac,4);
    shellac_remove_job(shellac,2);
    shellac_print_jobs(shellac);

    printf("\n---Remove 1---\n");
    shellac_remove_job(shellac,1);
    shellac_print_jobs(shellac);

    printf("\n---Remove All---\n");
    for(int i=0; i<6; i++){
      shellac_remove_job(shellac,i);
    }
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST



  IF_TEST("control bg 1") {
    // Add and start multiple background jobs to see that the array of
    // jobs is handled correctly. This test may be flaky due to the
    // concurrency involved.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[10][10] = {
      {"sleep", "0.10","&",NULL},
      {"sleep", "0.20","&",NULL},
      {"sleep", "0.30","&",NULL},
      {"sleep", "0.40","&",NULL},
    };
    for(int i=0; i<4; i++){
      shellac_add_job(shellac,job_new(args[i]));
      shellac_start_job(shellac,i);
    }
    printf("\n---Added jobs---\n");
    shellac_print_jobs(shellac);

    printf("\n---Update All---\n");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);

    printf("\n---First Sleep / Update All---\n");
    system("sleep 0.22");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);
    
    printf("\n---Second / Update All---\n");
    system("sleep 0.22");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST

  IF_TEST("control bg 2") {
    // Add and start multiple background jobs to see that the array of
    // jobs is handled correctly. New jobs are started later that
    // should fill into the gaps of the first few jobs. This test may
    // be flaky due to the concurrency involved.
    shellac_t *shellac = malloc(sizeof(shellac_t));
    shellac_init(shellac);
    char *args[10][10] = {
      {"sleep", "0.30","&",NULL},
      {"sleep", "0.10","&",NULL},
      {"sleep", "0.30","&",NULL},
      {"sleep", "0.40","&",NULL},
      {"sleep", "0.20","&",NULL},
    };
    for(int i=0; i<4; i++){
      shellac_add_job(shellac,job_new(args[i]));
      shellac_start_job(shellac,i);
    }
    printf("\n---Added 4 jobs---\n");
    shellac_print_jobs(shellac);

    printf("\n---Update All---\n");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);

    printf("\n---First Sleep / Update All---\n");
    system("sleep 0.22");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);
    
    printf("\n---Added and started 5th job---\n");
    shellac_add_job(shellac,job_new(args[4]));
    shellac_start_job(shellac,1);
    shellac_print_jobs(shellac);

    printf("\n---Second / Update All---\n");
    system("sleep 0.25");
    shellac_update_all(shellac);
    shellac_print_jobs(shellac);

    free(shellac);
  } // ENDTEST

    // char *args[10][10] = {
    //   {"gcc","myprog.c","-g",NULL},
    //   {"sleep", "5", NULL},
    //   {"seq", "5","6","36", NULL},
    //   {"ls", "-ld", NULL},
    //   {"ascii", "z", NULL},
    //   {"echo", "Here","goes","nothing", NULL},
    //   {""},
    // };


  if(nrun == 0){
    printf("No test named '%s' found\n",test_name);
    return 1;
  }

  return 0;
}
